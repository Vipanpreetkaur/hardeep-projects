//
//  List+CoreDataClass.swift
//  NoteTakingApp
//
//  Created by MacStudent on 2017-08-12.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation
import CoreData

@objc(List)
public class List: NSManagedObject {

}
