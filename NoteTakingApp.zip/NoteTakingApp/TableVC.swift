
//  NotesList+CoreDataClass.swift
//  NoteTakingApp
//  Created by Winners on 2017-11-24.
//  Copyright Winners. All rights reserved.

import UIKit
import CoreData

class TableVC: UITableViewController, NSFetchedResultsControllerDelegate {

    
    
    let context : NSManagedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var frc : NSFetchedResultsController <NSFetchRequestResult> = NSFetchedResultsController()
    
    func getFetchResultController() -> NSFetchedResultsController<NSFetchRequestResult>
    {
        frc = NSFetchedResultsController(fetchRequest: listFetchRequest(), managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        return frc
    }
    
    func listFetchRequest() -> NSFetchRequest<NSFetchRequestResult>
    {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "NotesList")
        let sortDescriptor = NSSortDescriptor(key: "note", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        return fetchRequest
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundView = UIImageView(image: UIImage(named: "background"))
       
        frc = getFetchResultController()
        frc.delegate = self
        do{
            try frc.performFetch()
        }catch{
            return
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        }
    
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.reloadData()
        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        let numberOfSections = frc.sections?.count
        return numberOfSections!
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let numberOfRowsInSection = frc.sections?[section].numberOfObjects
        return numberOfRowsInSection!
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! UITableViewCell
        
        let list = frc.object(at: indexPath)as! NotesList
        // Configure the cell...
        
        cell.textLabel?.text = list.note
        var latitude = list.latitude!
        var longtitude = list.longtitude!
        let date1 = Date()
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        
        cell.detailTextLabel?.text="\(formatter.string(from: date1))"
        cell.imageView?.image = UIImage(data: (list.image!) as Data)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let managedObject : NSManagedObject = frc.object(at: indexPath) as! NSManagedObject
        context.delete(managedObject)
        
        do {
            try context.save()
        } catch {
            print("Failed to save")
            return
        }

        
    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
        if segue.identifier == "Edit" {
            
            let cell = sender as! UITableViewCell
            let indexPath = tableView.indexPath(for: cell)
            let itemController : ViewController = segue.destination as! ViewController
            let item : NotesList = frc.object(at: indexPath!) as! NotesList
            
            
            itemController.nItem = item
            
        }

    }
    

}
