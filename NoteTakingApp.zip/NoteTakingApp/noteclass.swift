
//  NotesList+CoreDataClass.swift
//  NoteTakingApp
//  Created by Winners on 2017-11-24.
//  Copyright Winners. All rights reserved.
import Foundation
import CoreData

@objc(NotesList)
public class NotesList: NSManagedObject {

}
