
//  NotesList+CoreDataClass.swift
//  NoteTakingApp
//  Created by Winners on 2017-11-24.
//  Copyright Winners. All rights reserved.
import Foundation
import CoreData


extension NotesList {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<NotesList> {
        return NSFetchRequest<NotesList>(entityName: "NotesList");
    }

    @NSManaged public var image: NSData?
    @NSManaged public var note: String?
    @NSManaged public var latitude: String?
    @NSManaged public var longtitude: String?
    @NSManaged public var date: Date?

}
