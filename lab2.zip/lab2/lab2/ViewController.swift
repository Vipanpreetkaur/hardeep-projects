//
//  ViewController.swift
/Users/hardeep/Desktop/lab2/lab2/ViewController.swift//  lab2
//
//  Created by hardeep on 2017-11-25.
//  Copyright © 2017 hardeep. All rights reserved.
//

import UIKit
import MapKit
protocol HandleMapSearch: class {
    func dropPinZoomIn(_ placemark:MKPlacemark)
}

class ViewController: UIViewController {
    
    var selectedPin: MKPlacemark?
    var resultSeachController: UISearchController!
     let locationManager = CLLocationManager()
    
    @IBOutlet weak var mapView: MKMapView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        let locationSearchTable = storyboard!.instantiateInitialViewController(performSegue(withIdentifier: "LocationSearchTable") as! LocationSearchTable
            resultSeachController = UISearchController(searchResultsController: locationSearchTable)
        resultSearchController.searchResultsUpdater = locationSearchTable
        let searchBar = resultSeachController!.searchBar
        searchBar.sizeToFit()
        searchBar.placeholder = "search here"
        navigationItem.titleView = resultSeachController?.searchBar
        resultSeachController.hidesNavigationBarDuringPresentation = false
        resultSeachController.dimsBackgroundDuringPresentation = true
        definesPresentationContext = true
        locationSearchTable.mapView = mapView
        locationSearchTable.handleMapSearchDelegate = self
        
    }
    func getDirection() {
        guard let selectedPin = selectedPin else { return}
        let mapItem = MKMapItem(placemark: selectedPin)
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        mapItem.openInMaps(launchOptions: launchOptions)
    }
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
extension ViewController : CLLocationManagerDelegate {
    func locationManager(_manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
    {
        if status == .authorizedWhenInUse
        locationManager.requestLocation()
    }
}
func locationManager(_manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
{
    guard let location = locations.first else { return }
    let span = MKCoordinateRegion(center: location.coordinate, span: span)
    MKMapView.setRegion(region, animated: true)
}
func locationManager(_manager: CLLocationManager, didFaiWithError error: Error)
{
    print("error:: \(error)")
}}
extension ViewController: HandleMapSearch {
    func dropPinZoomIn(_ placemark: MKPlacemark) {
        selectedPin = placemark
        mapView.removeAnnotations(mapView.annotations)
        let annotation = MKPointAnnotation()
        annotation.coordinate = placemark.coordinate
        annotation.title = placemark.name
        
        if let city = placemark.locality,
            let state = placemark.administrativeArea {
            annotation.subtitle = "\"
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

